# Agent + Backend Portable Kit (v2.1)

Paquete portable para migrar el ecosistema de agentes y el backend semantico a otros repositorios (por ejemplo, FadeBooker).

## Contenido

- `github/`:
  - `system-orchestrator.agent.md`
  - `AGENTS.md`
  - `copilot-instructions.md`
  - `agents/` (study, data, programming, support)
  - `skills/`
  - `instructions/`
  - `prompts/`
- `backend/`:
  - `study_system/` (modulo Python completo)
  - `study_system_cli.py`
  - `extract_course_content.py`
  - `requirements_extraction.txt`
- `tools/package-manifest.txt`

## Instalacion en otro proyecto

1. Copiar el contenido de `github/` al directorio `.github/` del repositorio destino.
2. Copiar `backend/study_system/` a `src/study_system/` del repositorio destino.
3. Copiar scripts segun necesidad:
   - `backend/study_system_cli.py` -> `scripts/study_system_cli.py`
   - `backend/extract_course_content.py` -> `scripts/extract_course_content.py`
   - `backend/requirements_extraction.txt` -> `scripts/requirements_extraction.txt`
4. En el destino, instalar dependencias:
   - `pip install -r scripts/requirements_extraction.txt`
5. Regenerar knowledge base del proyecto destino:
   - `python scripts/extract_course_content.py`

## Nota

Este kit no incluye la carpeta `knowledge/` ni datasets para evitar transportar contenido pesado o especifico de un solo proyecto.
