#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Uso: $0 /ruta/al/repositorio-destino"
  exit 1
fi

TARGET="$1"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

mkdir -p "$TARGET/.github" "$TARGET/src" "$TARGET/scripts"

cp -r "$PKG_ROOT/github/"* "$TARGET/.github/"
cp -r "$PKG_ROOT/backend/study_system" "$TARGET/src/"
cp "$PKG_ROOT/backend/study_system_cli.py" "$TARGET/scripts/"
cp "$PKG_ROOT/backend/extract_course_content.py" "$TARGET/scripts/"
cp "$PKG_ROOT/backend/requirements_extraction.txt" "$TARGET/scripts/"

echo "Instalacion completada en: $TARGET"
echo "Siguiente paso:"
echo "  cd $TARGET"
echo "  pip install -r scripts/requirements_extraction.txt"
echo "  python scripts/extract_course_content.py"
